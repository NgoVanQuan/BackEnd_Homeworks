﻿using System.Text;
using Lap1._5;
class Program
{
    public static List<Student> students = new List<Student>()
    {
        new Student() { studentID = "1", studentName = "Nguyen Van A", age = 20, phone = "0333912821", address = "Hà Nội" },
        new Student() { studentID = "2", studentName = "Nguyen Van B", age = 20, phone = "0333912822", address = "Phú Thọ" },
        new Student() { studentID = "3", studentName = "Nguyen Van C", age = 20, phone = "0333912823", address = "Thái Bình" },
        new Student() { studentID = "4", studentName = "Nguyen Van D", age = 20, phone = "0333912824", address = "Hưng Yên" },
        new Student() { studentID = "5", studentName = "Nguyen Van E", age = 20, phone = "0333912825", address = "Hà Nội" },
    };
    // Them sinh vien
    public static bool addStudent(Student student)
    {
        try
        {
            bool isExit = students.Where(x => x.studentID == student.studentID).Count() > 0;
            if (isExit)
                throw new Exception("Sinh vien da ton tai!");
            students.Add(student);
            return true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            return false;
        }

    }
    // Sua sinh vien
    public static bool editStudent(Student student)
    {
        foreach (var item in students)
        {
            if (item.studentID == student.studentID)
            {
                item.studentName = student.studentName;
                item.age = student.age;
                item.phone = student.phone;
                item.address = student.address;
                return true;
            }
        }
        return false;
    }
    // Xoa sinh vien
    public static bool deleteStudent(Student student)
    {
        try
        {
            students.Remove(student);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static void getStudents()
    {
        Console.WriteLine("ID\tNAME\t\tAGE\tPHONE\t\tADDRESS");
        foreach (var item in students)
        {

            Console.WriteLine($"{item.studentID}\t{item.studentName}\t{item.age}\t{item.phone}\t{item.address}");
        }
    }
    public static void alert(bool isSuccess, string action)
    {
        string message = isSuccess ? $"{action} thành công!" : $"{action} thất bại!";
        Console.WriteLine(message);
        Console.WriteLine("Press any key to continue...");
        Console.ReadLine();
    }
    public static void getMenu()
    {
        int n;
        do
        {
            Console.Clear();
            Console.WriteLine("-----------------------Quản lý sinh viên-----------------------");
            getStudents();
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("\t1. Thêm sinh viên");
            Console.WriteLine("\t2. Sửa sinh viên");
            Console.WriteLine("\t3. Xoá sinh viên");
            Console.WriteLine("\t4. Thoát");
            do
            {
                Console.Write("- Mời bạn chọn chức năng: ");
                n = int.Parse(Console.ReadLine());
            } while (n > 4 || n < 1);
            switch (n)
            {
                case 1:
                    {
                        Student student = new Student();
                        Console.Write("- Nhập ID: ");
                        student.studentID = Console.ReadLine();
                        Console.Write("- Nhập họ tên: ");
                        student.studentName = Console.ReadLine();
                        Console.Write("- Nhập tuổi: ");
                        student.studentName = Console.ReadLine();
                        Console.Write("- Nhập địa chỉ: ");
                        student.address = Console.ReadLine();
                        Console.Write("- Nhập số điện thoại: ");
                        student.phone = Console.ReadLine();
                        alert(addStudent(student), "Thêm");
                    }
                    break;
                case 2:
                    {
                        Console.Write("- Chọn ID sinh viên muốn sửa: ");
                        string id = Console.ReadLine();
                        Student student = students.First(x => x.studentID == id);
                        Console.Write("- Nhập họ tên: ");
                        student.studentName = Console.ReadLine();
                        Console.Write("- Nhập tuổi: ");
                        student.studentName = Console.ReadLine();
                        Console.Write("- Nhập địa chỉ: ");
                        student.address = Console.ReadLine();
                        Console.Write("- Nhập số điện thoại: ");
                        student.phone = Console.ReadLine();
                        editStudent(student);
                        alert(editStudent(student), "Sửa");
                    }
                    break;
                case 3:
                    {
                        Console.Write("- Chọn ID sinh viên muốn xoá: ");
                        string id = Console.ReadLine();
                        alert(deleteStudent(students.First(x => x.studentID == id)),
    "Xoá");
                    }
                    break;
                default:
                    break;
            }
        } while (n != 4);
    }
    static void Main(string[] args)
    {
        //Config Console Output được Tiếng Việt 
        Console.OutputEncoding = Encoding.UTF8;
        getMenu();
    }
   
}

