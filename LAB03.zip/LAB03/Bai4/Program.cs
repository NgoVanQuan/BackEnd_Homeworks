﻿using System;
using Bai4;
namespace Bai3
{
    class Program
    {
        public static void Main(string[] args)
        {
            KhuPho khuPho = new KhuPho();
            while (true)
            {
                Console.WriteLine("-----------MENU----------");
                Console.WriteLine("1. Nhap thong tin ca ho dan.");
                Console.WriteLine("2. Hien thi thong tin toan bo cac ho dan trong khu pho.");
                Console.WriteLine("3. Tim kiem ho dan theo ten.");
                Console.WriteLine("4. Tim kiem ho dan theo so nha");
                Console.WriteLine("5. Thoat");
                Console.WriteLine("Chon chuc nang: ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        khuPho.Nhap();
                        break;
                    case 2:
                        khuPho.HienThi();
                        break;
                    case 3:
                        Console.WriteLine("Nhap ho ten can tim: ");
                        string hoTen = Console.ReadLine();
                        khuPho.TimKiemTheoTen(hoTen);
                        break;
                    case 4:
                        Console.WriteLine("Nhap so nha can tim: ");
                        int soNha = int.Parse(Console.ReadLine());
                        khuPho.TimKiemTheoSoNha(soNha);
                        break;
                    case 5:
                        Console.WriteLine("Chuong trinh ket thuc!");
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le!");
                        break;
                        return;
                }
            }
        }
    }
}