﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai4
{
    class Hodan
    {
        public int soNha { get; set; }
        private int soThanhVien { get; set; }

        public List<Nguoi> ThanhVien { get; set; }

        public Hodan()
        {
            ThanhVien = new List<Nguoi>();
        }
        public void Nhap()
        {
            Console.Write("Nhap so nha: ");
            soNha = int.Parse(Console.ReadLine());
            Console.Write("Nhap so thanh vien: ");
            soThanhVien = int.Parse(Console.ReadLine());

            for (int i = 0; i < soThanhVien; i++)
            {
                Console.WriteLine($"Nhap so thanh vien tu {i + 1}");
                Nguoi nguoi = new Nguoi();
                nguoi.Nhap();
                ThanhVien.Add(nguoi);
            }
        }
        public void HienThi()
        {
            Console.WriteLine($"So nha: {soNha} \n So thanh vien trong gia dinh: {soThanhVien}");
            foreach (var nguoi in ThanhVien)
            {
                nguoi.HienThi();
            }
        }
    }
}
