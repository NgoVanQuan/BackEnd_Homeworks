﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai4
{
    class KhuPho
    {
        public List<Hodan> listHoDan { get; set; }
        public KhuPho()
        {
            listHoDan = new List<Hodan>();
        }
        public void Nhap()
        {
            Console.WriteLine("Nhap so luong ho dan: ");
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Nhap thong tin ho dan thu {i + 1}: ");
                Hodan hodan = new Hodan();
                hodan.Nhap();
                listHoDan.Add(hodan);
            }
        }
        public void HienThi()
        {
            foreach (var hodan in listHoDan)
            {
                hodan.HienThi();
                Console.WriteLine("----------------");
            }
        }
        public void TimKiemTheoTen(string hoTen)
        {
            bool search = false;
            foreach (var hoDan in listHoDan)
            {
                foreach (var nguoi in hoDan.ThanhVien)
                {
                    if (nguoi.hoTen.Equals(hoTen, StringComparison.OrdinalIgnoreCase))
                    {

                        Console.WriteLine($"Tim thay nguoi ten {hoTen} trong ho dan trong so nha {hoDan.soNha}");
                        hoDan.HienThi();
                        search = true;
                        break;
                    }
                }
            }
            if (!search)
            {
                Console.WriteLine("Khong tim thay ho dan!");
            }
        }
        public void TimKiemTheoSoNha(int soNha)
        {
            bool seach = false;
            foreach (var hoDan in listHoDan)
            {
                if (hoDan.soNha.Equals(soNha))
                {
                    Console.WriteLine($"Tim thay ho dan o so nha {soNha}");
                    hoDan.HienThi();
                    seach = true;
                    break;
                }
            }
            if (!seach)
            {
                Console.WriteLine("Khong tim thay ho dan o so nha do!");
            }
        }

    }
}
