﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai4
{
    class Nguoi
    {
        private int soCMT {  get; set; }
        public string hoTen {  get; set; }
        private int tuoi {  get; set; }
        private int namSinh { get; set; }
        private string ngheNghiep { get; set; }

        public void Nhap()
        {
            Console.WriteLine("Nhap so chung minh nhan dan: ");
            soCMT = int.Parse(Console.ReadLine());
            Console.WriteLine("Ho ten: ");
            hoTen = Console.ReadLine();
            Console.WriteLine("Tuoi: ");
            tuoi = int.Parse(Console.ReadLine());
            Console.WriteLine("Nam sinh: ");
            namSinh = int.Parse(Console.ReadLine());
            Console.WriteLine("Nghe nghiep: ");
            ngheNghiep = Console.ReadLine();
        }
        public void HienThi()
        {
            Console.WriteLine($"So chung minh thu: {soCMT} \n Ho ten: {hoTen} \n Tuoi: {tuoi} \n Nam sinh: {namSinh} \n Nghe nghiep: {ngheNghiep} ");
        }
    }
}
