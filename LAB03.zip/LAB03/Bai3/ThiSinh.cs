﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    public class ThiSinh
    {
        public int soBaoDanh { get; set; }
        public string hoTen { get; set; }
        public string diaChi { get; set; }
        public float uuTien { get; set; }

        public ThiSinh(int soBaoDanh, string hoTen, string diaChi, float uuTien)
        {
            this.soBaoDanh = soBaoDanh;
            this.hoTen = hoTen;
            this.diaChi = diaChi;
            this.uuTien = uuTien;
        }
        public virtual void Nhap()
        {
            Console.WriteLine("So bao danh: ");
            soBaoDanh = int.Parse(Console.ReadLine());
            Console.WriteLine("Ho va ten: ");
            hoTen = Console.ReadLine();
            Console.WriteLine("Dia chi: ");
            diaChi = Console.ReadLine();
            Console.WriteLine("Diem uu tien khu vuc: ");
            uuTien = float.Parse(Console.ReadLine());
        }
        public virtual float TinhTongDiem()
        {
            return 0;
        }
        public string toString()
        {
            return $"So bao danh thi sinh {soBaoDanh}, Ho va ten: {hoTen}, " +
                $"Dia chi: {diaChi}, Diem uu tien khu vuc: {uuTien}";
        }
    }
}
