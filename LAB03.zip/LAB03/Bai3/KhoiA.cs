﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    class KhoiA : ThiSinh
    {
        private float toan { get; set; }
        private float ly { get; set; }
        private float hoa { get; set; }
        
        public KhoiA(int soBaoDanh, string hoTen, string diaChi, int uuTien, float toan, float ly, float hoa)
            : base(soBaoDanh, hoTen, diaChi, uuTien)
        {
            this.toan = toan;
            this.ly = ly;
            this.hoa = hoa;
        }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap diem Toan: ");
            toan = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Ly: ");
            ly = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Hoa: ");
            hoa = float.Parse(Console.ReadLine());
        }
        public override float TinhTongDiem()
        {
            return toan + ly + hoa + uuTien;
        }
    }
}
