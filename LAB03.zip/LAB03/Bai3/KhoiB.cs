﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    class KhoiB : ThiSinh
    {
        private float toan { get; set; }
        private float hoa { get; set; }
        private float sinh { get; set; }
        public KhoiB(int soBaoDanh, string hoTen, string diaChi, int uuTien, float toan, float hoa, float sinh)
            : base(soBaoDanh, hoTen, diaChi, uuTien)
        {
            this.toan = toan;
            this.hoa = hoa;
            this.sinh = sinh;
        }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap diem Toan: ");
            toan = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Hoa: ");
            hoa = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Sinh: ");
            sinh = float.Parse(Console.ReadLine());
        }
        public override float TinhTongDiem()
        {
            return toan + hoa + sinh + uuTien;
        }
    }
}
