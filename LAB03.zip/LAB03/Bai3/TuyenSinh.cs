﻿using System;
using System.Collections.Generic;

namespace Bai3
{
    class TuyenSinh
    {
        private List<ThiSinh> list = new List<ThiSinh>();

        public void NhapThongTin()
        {
            while (true)
            {
                Console.WriteLine("Chon khoi (A / B / C) hoac chon (E) de thoat:");
                string luaChon = Console.ReadLine().ToUpper();
                if (luaChon == "E") break;

                ThiSinh thiSinh = null;
                if (luaChon.Trim() == "A")
                {
                    thiSinh = new KhoiA(0, "", "", 0, 0, 0, 0);
                }
                else if (luaChon.Trim() == "B")
                {
                    thiSinh = new KhoiB(0, "", "", 0, 0, 0, 0);
                }
                else if (luaChon.Trim() == "C")
                {
                    thiSinh = new KhoiC(0, "", "", 0, 0, 0, 0);
                }
                else
                {
                    Console.WriteLine("Lua chon khong hop le!");
                    continue;
                }

                thiSinh.Nhap();
                list.Add(thiSinh);
            }
        }

        public void HienThiTrungTuyen()
        {
            Console.WriteLine("Diem chuan khoi A: ");
            float diemChuanA = float.Parse(Console.ReadLine());
            Console.WriteLine("Diem chuan khoi B: ");
            float diemChuanB = float.Parse(Console.ReadLine());
            Console.WriteLine("Diem chuan khoi C: ");
            float diemChuanC = float.Parse(Console.ReadLine());
            Console.WriteLine("Thong tin cua thi sinh trung tuyen: ");
            foreach (var thiSinh in list)
            {
                float tongDiem = thiSinh.TinhTongDiem(); 
                if (thiSinh is KhoiA a && tongDiem >= diemChuanA)
                {
                    Console.WriteLine($"{a.hoTen} - {a.soBaoDanh} - Tong diem: {tongDiem}");
                }
                else if (thiSinh is KhoiB b && tongDiem >= diemChuanB)
                {
                    Console.WriteLine($"{b.hoTen} - {b.soBaoDanh} - Tong diem: {tongDiem}");
                }
                else if (thiSinh is KhoiC c && tongDiem >= diemChuanC)
                {
                    Console.WriteLine($"{c.hoTen} - {c.soBaoDanh} - Tong diem: {tongDiem}");
                }
            }
        }
        public void TimKiem()
        {
            Console.WriteLine("Nhap so bao danh thi sinh can tim: ");
            int soBaoDanh = int.Parse(Console.ReadLine());
            foreach (var thiSinh in list)
            {
                if (thiSinh.soBaoDanh == soBaoDanh)
                {
                    Console.WriteLine(thiSinh.toString());
                    return;
                }
            }
            Console.WriteLine($"Khong tim thay thi sinh!");
        }
        public void KetThuc()
        {
            Console.WriteLine("Ket thuc chuong trinh.");
        }
    }
}
