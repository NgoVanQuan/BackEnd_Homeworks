﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    class KhoiC : ThiSinh
    {
        private float van { get; set; }
        private float su { get; set; }
        private float dia { get; set; }
        public KhoiC(int soBaoDanh, string hoTen, string diaChi, int uuTien, float van, float su, float dia)
            : base(soBaoDanh, hoTen, diaChi, uuTien)
        {
            this.van = van;
            this.su = su;
            this.dia = dia;
        }
        public  override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap diem Van: ");
            van = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Su: ");
            su = float.Parse(Console.ReadLine());
            Console.WriteLine("Nhap diem Dia: ");
            dia = float.Parse(Console.ReadLine());

        }
        public override float TinhTongDiem()
        {
            return van + su + dia + uuTien;
        }
    }
}
