﻿using System;
namespace Bai3
{
    class Program
    {
        public static void Main(string[] args)
        {
            TuyenSinh tuyenSinh = new TuyenSinh();
            while (true)
            {
                Console.WriteLine("\n1. Nhap thong tin thi sinh.");
                Console.WriteLine("2. Hien thi thong tin thi sinh trung tuyen.");
                Console.WriteLine("3. Tim kiem thi sinh theo so bao danh.");
                Console.WriteLine("4. Ket thuc chuong trinh.");
                Console.WriteLine("Chon chuc nang: ");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        tuyenSinh.NhapThongTin();
                        break;
                    case 2:
                        tuyenSinh.HienThiTrungTuyen();
                        break;
                    case 3:
                        tuyenSinh.TimKiem();
                        break;
                    case 4:
                        tuyenSinh.KetThuc();
                        break;
                    default:
                        Console.WriteLine("Lua chon khong hop le!");
                        break;
                }
            }

        }
    }
}