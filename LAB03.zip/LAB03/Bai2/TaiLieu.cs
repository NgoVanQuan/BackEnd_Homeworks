﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class TaiLieu
    {
        private int idTaiLieu { get; set; }
        private string tenNhaXuatBan { get; set; }
        private int soBanPhatHanh { get; set; }

        public TaiLieu(int idTaiLieu, string tenNhaXuatBan, int soBanPhatHanh)
        {
            this.idTaiLieu = idTaiLieu;
            this.tenNhaXuatBan = tenNhaXuatBan;
            this.soBanPhatHanh = soBanPhatHanh;
        }

        public void Nhap()
        {
            Console.WriteLine("Nhap ma tai lieu: ");
            idTaiLieu = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhap ten nha san xuat: ");
            tenNhaXuatBan = Console.ReadLine();
            Console.WriteLine("Nhap so ban phat hanh: ");
            soBanPhatHanh = int.Parse(Console.ReadLine());
        }
        public void HienThi()
        {
            Console.WriteLine($"ID: {idTaiLieu}, Ten nha san xuat: {tenNhaXuatBan}, So ban phat hanh: {soBanPhatHanh}");
        }
    }
}
