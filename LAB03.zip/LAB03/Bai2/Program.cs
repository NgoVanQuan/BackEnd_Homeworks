﻿using System;

namespace Bai2
{
    class Program
    {
        public static void Main(string[] args)
        {
            QuanLyTaiLieu qltl = new QuanLyTaiLieu();
            bool choit = true;

            while (choit)
            {
                Console.WriteLine("Chon chuc nang: ");
                Console.WriteLine("1. Nhap thong tin tai lieu.");
                Console.WriteLine("2.Hien thi thong tin va cac tai lieu.");
                Console.WriteLine("3. Tim kiem tai lieu theo id.");
                Console.WriteLine("4. Thoat chuong trinh.");
                int luaChon = int.Parse(Console.ReadLine());
                switch (luaChon)
                {
                    case 1:
                        qltl.NhapTaiLieu();
                        break;
                    case 2:
                        qltl.HienThiTaiLieu();
                        break;
                    case 3:
                        Console.WriteLine("Nhap id tai lieu can tim: ");
                        int idTaiLieu = int.Parse(Console.ReadLine());
                        qltl.TimKiem(idTaiLieu);
                        break;
                    case 4:
                        choit = false;
                        break;
                    default:
                        Console.WriteLine("Chuc nang khong hop le!");
                        break;

                }
            }
        }
    }
}