﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{

    public class Sach : TaiLieu
    {
        private string tenTacGia;
        private int soTrang;
        public Sach(int idTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, string tenTacGia, int soTrang)
            : base(idTaiLieu, tenNhaXuatBan, soBanPhatHanh)
        {
            this.tenTacGia = tenTacGia;
            this.soTrang = soTrang;
        }
        public void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap ten tac gia: ");
            tenTacGia = Console.ReadLine();
            Console.WriteLine("Nhap so trangL: ");
            soTrang = int.Parse(Console.ReadLine());
        }
        public void HienThiSach()
        {
            base.HienThi();
            Console.WriteLine($"Ten tac gia: {tenTacGia}, So trang: {soTrang}");
        }

    }
}
