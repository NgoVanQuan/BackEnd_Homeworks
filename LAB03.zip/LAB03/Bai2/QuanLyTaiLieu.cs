﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class QuanLyTaiLieu
    {
        private List<TaiLieu> list = new List<TaiLieu>();
        public void NhapTaiLieu()
        {
            Console.WriteLine("------- Nhap thong tin --------");
            Console.WriteLine("1. Sach.");
            Console.WriteLine("2. Tap chi.");
            Console.WriteLine("3. Bao.");
            int luaChon = int.Parse(Console.ReadLine());
            TaiLieu taiLieu = null;
            switch (luaChon)
            {
                case 1:
                    taiLieu = new Sach(0, " ", 0, "", 0);
                    taiLieu.Nhap();
                    break;
                case 2:
                    taiLieu = new TapChi(0, " ", 0, 0, 0);
                    taiLieu.Nhap();
                    break;
                case 3:
                    taiLieu = new Bao(0, " ", 0, 0);
                    taiLieu.Nhap();
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    return;
            }
            list.Add(taiLieu);
        }
        public void TimKiem(int idTaiLieu)
        {
            foreach (var taiLieu in list)
            {
                if (taiLieu.Equals(idTaiLieu))
                {
                    taiLieu.HienThi();
                    return;
                }
            }
            Console.WriteLine("Khong tim thay can bo!");
        }
        public void HienThiTaiLieu()
        {
            foreach (var taiLieu in list)
            {
                taiLieu.HienThi();
                Console.WriteLine("----------------");
            }
        }

    }
}
