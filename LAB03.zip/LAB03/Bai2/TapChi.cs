﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class TapChi : TaiLieu
    {
        private int soPhatHanh { get; set; }
        private int thangPhatHanh { get; set; }
        public TapChi(int idTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, int soPhatHanh, int thangPhatHanh)
            : base(idTaiLieu, tenNhaXuatBan, soBanPhatHanh)
        {
            this.soPhatHanh = soBanPhatHanh;
            this.thangPhatHanh = thangPhatHanh;
        }
        public void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap so phat hanh: ");
            soPhatHanh = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhap thang phat hanh: ");
            thangPhatHanh = int.Parse(Console.ReadLine());
        }
        public void HienThiTapChi()
        {
            base.HienThi();
            Console.WriteLine($"So phat hanh: {soPhatHanh}, Thang phat hanh: {thangPhatHanh}");

        }
    }
}
