﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    public class Bao : TaiLieu
    {
        private int ngayPhatHanh { get; set; }
        public Bao(int idTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, int ngayPhatHanh)
            : base(idTaiLieu, tenNhaXuatBan, soBanPhatHanh)
        {
            this.ngayPhatHanh = ngayPhatHanh;
        }
        public void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap ngay phat hanh: ");
            ngayPhatHanh = int.Parse(Console.ReadLine());

        }
        public void HienThiNgay()
        {
            base.HienThi();
            Console.WriteLine($"Ngay phat hanh: {ngayPhatHanh}");
        }
    }
}
