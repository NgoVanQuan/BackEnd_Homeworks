﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap1
{
    public class KySu : CanBo
    {
        public string ngheNghiep { get; set; }
        public KySu(string fullname, int birthday, string sex, string adress, string ngheNghiep)
            : base(fullname, birthday, sex, adress)
        {
            this.ngheNghiep = ngheNghiep;
        }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap nganh dao tao: ");
            ngheNghiep = Console.ReadLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Nghe Nghiep: {ngheNghiep}");
        }
    }
}

