﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap1
{
    public class QLCB
    {
        private List<CanBo> ds = new List<CanBo>();
        public void NhapCanBo()
        {
            Console.WriteLine("-----Nhap thong tin cho-----");
            Console.WriteLine("1. Cong nhan");
            Console.WriteLine("2. Ky su");
            Console.WriteLine("3. Nhan vien");
            int choose = int.Parse(Console.ReadLine());
            CanBo canBo = null;
            switch (choose)
            {
                case 1:

                    canBo = new CongNhan("", 0, "", " ", "");
                    canBo.Nhap();
                    break;
                case 2:
                    canBo = new KySu("", 0, "", " ", "");
                    canBo.Nhap();
                    break;
                case 3:
                    canBo = new NhanVien("", 0, "", " ", "");
                    canBo.Nhap();
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    return;
            }

            ds.Add(canBo);
        }
        public void TimKiem(string fullName)
        {
            foreach (var canBo in ds)
            {
                if (canBo.fullName.Equals(fullName, StringComparison.OrdinalIgnoreCase))
                {
                    canBo.HienThi();
                    return;
                }
            }
            Console.WriteLine("Khong tim thay can bo.");
        }
        public void HienThiDanhSach()
        {
            foreach (var canBo in ds)
            {
                canBo.HienThi();
                Console.WriteLine("------------");
            }
        }
    }
}
