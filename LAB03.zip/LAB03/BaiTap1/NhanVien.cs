﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap1
{
    public class NhanVien : CanBo
    {
        public string congViec { get; set; }
        public NhanVien(string fullname, int birthday, string sex, string adress, string congviec)
            : base(fullname, birthday, sex, adress)
        {
            this.congViec = congViec;
        }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap ten cong viec: ");
            congViec = Console.ReadLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Cong viec: {congViec}");
        }
    }
}
