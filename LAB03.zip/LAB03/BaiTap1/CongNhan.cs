﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap1
{
    public class CongNhan : CanBo
    {
        private string bac { get; set; }
        public CongNhan(string fullname, int birthday, string sex, string adress, string bac)
            : base(fullname, birthday, sex, adress)
        {
            this.bac = bac;
        }
        public override void Nhap()
        {
            base.Nhap();
            Console.WriteLine("Nhap bac: ");
            bac = Console.ReadLine();
        }
        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Bac: {bac}");
        }
    }
}
