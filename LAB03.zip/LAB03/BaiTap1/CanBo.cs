﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap1
{
    public class CanBo
    {
        public string fullName { get; set; }
        public int birthday { get; set; }
        public string sex { get; set; }
        public string adress { get; set; }

        public CanBo(string fullName, int birthday, string sex, string adress)
        {
            this.fullName = fullName;
            this.birthday = birthday;
            this.sex = sex;
            this.adress = adress;
        }

        public virtual void Nhap()
        {
            Console.WriteLine("Nhap ho ten: ");
            fullName = Console.ReadLine();
            Console.WriteLine("Nhap nam sinh: ");
            birthday = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhap gioi tinh: ");
            sex = Console.ReadLine();
            Console.WriteLine("Nhap dia chi: ");
            adress = Console.ReadLine();

        }
        public virtual void HienThi()
        {
            Console.WriteLine($"Ho ten: {fullName}, Nam sinh: {birthday}, Gioi tinh: {sex}, Dia chi: {adress} ");
        }

    }
}
